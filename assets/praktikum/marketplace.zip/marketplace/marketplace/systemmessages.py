# Status: FINAL, dgaida2, 15.10.2024

# Definiert die Klasse SystemMessages
# über die Methode push() können Nachrichten in der Warteschlange gespeichert werden.
# Nachrichten in der Warteschlange werden nacheinander in dem tk.Label _lbl_sysmessage
# für 5 Sekunden angezeigt, bis keine Nachrichten mehr in der Warteschlange existieren.
# in der GUI werden diese Nachrichten oben links angezeigt.

from typing import Callable, Optional


class SystemMessages:
    """Manages system notification messages via an abstract callback mechanism."""

    # *** CONSTRUCTORS ***
    def __init__(self, target=None, update_callback: Optional[Callable[[str, str], None]] = None, after_callback: Optional[Callable[[int, Callable], None]] = None):
        """Initializes SystemMessages with a widget target or UI update and timer callbacks.

        Args:
            target (optional): Tkinter label or object with config and after methods for backward compatibility.
            update_callback (Callable[[str, str], None], optional): Function accepting (text, bg_color).
            after_callback (Callable[[int, Callable], None], optional): Function accepting (ms, callback_fn).
        """
        self._queue = []
        self._lbl_sysmessage = target if (target is not None and hasattr(target, "config")) else None
        if self._lbl_sysmessage is not None:
            self._update_callback = lambda text, bg: self._lbl_sysmessage.config(text=text, bg=bg)
            self._after_callback = lambda ms, fn: self._lbl_sysmessage.after(ms, fn)
        else:
            self._update_callback = update_callback
            self._after_callback = after_callback
        self._displaying = False

    # *** PUBLIC SET methods ***

    # *** PUBLIC methods ***

    def push(self, message):
        self._queue.append(message)
        if not self._displaying:
            self._display_next_message()

    # *** PUBLIC GET methods ***

    # *** PUBLIC STATIC methods ***

    # *** PRIVATE methods ***

    def _display_next_message(self):
        if not self._queue:
            self._displaying = False
            if self._lbl_sysmessage is not None:
                try:
                    default_bg = self._lbl_sysmessage.master["bg"]
                except Exception:
                    # TODO: wirft einen Fehler, die Farbe vom master zu bekommen (nicht so wichtig)
                    default_bg = '#d9d9d9'
                self._update_callback("-", default_bg)
            elif self._update_callback:
                self._update_callback("-", "#d9d9d9")
            return

        self._displaying = True
        message = self._queue.pop(0)
        if self._update_callback:
            self._update_callback(message, "yellow")

        if len(self._queue) == 0:
            display_time = 15  # 15 seconds for the last message
        else:
            display_time = 3  # 3 seconds for other messages

        if self._after_callback:
            self._after_callback(display_time * 1000, self._display_next_message)

    # *** PUBLIC methods to return class properties ***

    # *** PRIVATE variables ***
