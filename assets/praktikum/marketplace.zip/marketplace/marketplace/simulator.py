# Status: Not FINAL, dgaida2, 15.10.2024

import threading
import random
import time
import marketplace.users


class Simulator:
    def __init__(self):
        self.stop_simulation = False

    def place_random_bids(self, auctions, current_user_id, num_auctions=10):
        if self.stop_simulation:
            return

        users = auctions.users()

        user_ids = [user_id for user_id in users.keys() if user_id != current_user_id]

        auctions._place_random_bids(num_auctions, user_ids, True, current_user_id)

        # auction_ids = list(auctions.keys())
        #
        # for _ in range(num_auctions):
        #     random_user = random.choice(user_ids)
        #     random_auction = random.choice(auction_ids)
        #
        #     min_bid = auctions.get_item_value_min(random_auction)
        #
        #     random_bid = min_bid + random.randint(1, 50)
        #     auctions.bid_in_auction(random_auction, users[random_user], random_bid)
        #
        #     # prüfen, ob Angebot des curent_user überboten wurde, falls er in dieser Auktion bietet und
        #     # falls ja, dann systemnachricht ausgeben.
        #     bid_by_current_customer = auctions.get_bid_of_user(random_auction, current_user_id)
        #     if bid_by_current_customer is not None and bid_by_current_customer < random_bid:
        #         print('Angebot von current_user wurde überboten')
        #         print('Letzte Auktion kam von Nutzer {0}, das steht auch im Stapel: {1}'.format(
        #             random_user, auctions.get_last_bid(random_auction)))

        # threading.Timer(30, self.place_random_bids, args=(auctions, current_user_id)).start()

    def create_random_auctions(self, auctions, current_user_id):
        if self.stop_simulation:
            return

        user_ids = [user_id for user_id in auctions.users().keys() if user_id != current_user_id]

        for _ in range(5):
            random_user = random.choice(user_ids)
            item_name = "Kartoffelschäler"
            description = ""
            value_min = 1
            auctions.add_new_auction(random_user, item_name, description, value_min)

        # threading.Timer(30, self.create_random_auctions, args=(auctions, current_user_id)).start()

    def randomly_rate_users(self, users: marketplace.users.Users, current_user_id):
        if self.stop_simulation:
            return

        user_ids = [user_id for user_id in users.keys() if user_id != current_user_id]

        for _ in range(35):
            random_user = random.choice(user_ids)
            stars = random.randint(1,5)
            users[random_user].rate_user(stars)

    def stop(self):
        self.stop_simulation = True


