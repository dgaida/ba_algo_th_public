"""Übersicht über den Dateiinhalt:

Implementiert die Disjoint-Set-Datenstruktur (Union-Find) mit `SetNode` und `Praktikumsgruppen`.
Ermöglicht das Zusammenfassen von Benutzern in Praktikumsgruppen (Gruppenbildung,
Union, Find mit Pfadkomprimierung).
"""

# Status: FINAL, dgaida2, 15.10.2024

# Definiert die Klassen Praktikumsgruppen und SetNode, implementiert als Menge von disjunkten Mengen (Praktikum 3) oder als Dictionary (Praktikum 1 und 2)
#
from typing import Any, List, Optional, Union


class SetNode:
    """Klasse zur Repräsentation eines Knotens in einer Disjoint-Set-Struktur (Union-Find).

    Attributes:
        _parent (SetNode): Zeiger auf den Eltern-Knoten (self bei Wurzeln).
        _weight (int): Anzahl der Knoten im Teilbaum.
    """

    # TODO for students: die Klasse user.User erbt von SetNode. diese Klasse wird eigentlich erst in Praktikum 3 benötigt.
    #     für Praktikum 1 und 2 müsste User nicht von dieser Klasse erben

    # *** CONSTRUCTORS ***
    def __init__(self) -> None:
        """Initialisiert einen SetNode als eigene Wurzel mit Gewicht 1.

        Args:
            None

        Raises:
            None
        """
        # TODO: werden nur für Praktikum 3 benötigt
        self._parent: SetNode = self   # parent Knoten des SetNode Objekts. self bedeutet, dass der Knoten ein Wurzelknoten ist
        self._weight: int = 1      # Gewicht (Anzahl Knoten) des (Teil-)Baumes, der in dem SetNode Objekt verwurzelt ist
        # Alternative: Rank-based Quick Union
        # self._rank = 0

    # *** PUBLIC SET methods ***

    def inc_weight(self, inc_by: int) -> None:
        """Erhöht das Gewicht des Teilbaums um den angegebenen Wert.

        Args:
            inc_by (int): Erhöhungsbetrag.

        Returns:
            None

        Raises:
            None
        """
        self._weight += inc_by

    # def inc_rank(self):
    #   self._rank += 1

    def set_parent(self, parent: 'SetNode') -> None:
        """Setzt den Elternknoten.

        Args:
            parent (SetNode): Neuer Elternknoten.

        Returns:
            None

        Raises:
            None
        """
        self._parent = parent

    # *** PUBLIC methods to return class properties ***

    def weight(self) -> int:
        """Gibt das Gewicht des Teilbaums zurück.

        Args:
            None

        Returns:
            int: Gewicht des Teilbaums.

        Raises:
            None
        """
        return self._weight

    # def rank(self):
    #   return self._rank

    def parent(self) -> 'SetNode':
        """Gibt den Elternknoten zurück.

        Args:
            None

        Returns:
            SetNode: Elternknoten.

        Raises:
            None
        """
        return self._parent


class Praktikumsgruppen(dict):
    """Klasse zur Repräsentation einer Sammlung disjunkter Mengen (Praktikumsgruppen).

    In Praktikum 1 und 2: Dictionary containing all students. Die Klasse user.Users erbt von dieser Klasse.
    In Praktikum 3: Class representing a collection of disjoint sets for grouping users into practical groups.

    Methods:
        find(node): Finds the root of the set containing the node, with path compression.
        find_byid(user_id, return_id=False): Finds the root of the set containing the user by ID.
        union(user_id1, user_id2): Unions the sets containing the two users.
        create_groups(user_ids, groupnumbers): Creates groups from the provided user IDs and group numbers.
        get_groupmembers(user_id): Gets the members of the group containing the user.
        print_ds(): Prints the disjoint set structure.

    Attributes:
        None (erbt von dict).
    """

    # *** CONSTRUCTORS ***
    def __init__(self) -> None:
        """Initialisiert eine neue Praktikumsgruppen-Instanz.

        Args:
            None

        Raises:
            None
        """
        super().__init__()

    # *** PUBLIC methods ***

    def find(self, node: Any) -> Any:
        """Findet die Wurzel der Menge mit Pfadkomprimierung.

        Args:
            node (Any): Der Ausgangsknoten (User/SetNode).

        Returns:
            Any: Der Wurzelknoten der Menge.

        Raises:
            None
        """
        if node.parent() != node:
            node.set_parent(self.find(node.parent()))  # Path compression
        return node.parent()

    # TODO students: die Methode existiert nur aus Kompatibilitätsgründen und wird im 3. Praktikum implementiert
    def find_byid(self, user_id: str, return_id: bool = False) -> Union[Any, str]:
        """Findet die Wurzel der Praktikumsgruppe eines Benutzers anhand seiner ID.

        Args:
            user_id (str): Benutzer-ID.
            return_id (bool): Wenn `True`, wird die Benutzer-ID der Wurzel zurückgegeben.

        Returns:
            Union[Any, str]: Das Wurzelobjekt oder dessen ID.

        Raises:
            KeyError: Falls `user_id` nicht im Wörterbuch existiert.
        """
        # dieses node Objekt ist ein marketplace.user.User Objekt, da in users im Konstruktor alle User Objekte
        # in Hashtabelle von Users gespeichert wurden. auf diese wird hier zugegriffen
        node = self[user_id]
        root = self.find(node)

        if return_id:
            return root.id()
        else:
            return root

    def union(self, user_id1: str, user_id2: str) -> None:
        """Vereinigt die Praktikumsgruppen zweier Benutzer.

        Args:
            user_id1 (str): ID des ersten Benutzers.
            user_id2 (str): ID des zweiten Benutzers.

        Returns:
            None

        Raises:
            KeyError: Falls einer der Benutzer nicht im Wörterbuch existiert.
        """
        root1 = self.find_byid(user_id1)
        root2 = self.find_byid(user_id2)

        if root1 != root2:
            if root1.weight() > root2.weight():
                root2.set_parent(root1)
                root1.inc_weight(root2.weight())
            # elif root1.rank() < root2.rank():
            #   root1.set_parent(root2)
            else:
                root1.set_parent(root2)
                root2.inc_weight(root1.weight())
                # root1.inc_rank()

    def create_groups(self, user_ids: List[str], groupnumbers: List[int]) -> None:
        """Erstellt Praktikumsgruppen aus Benutzer-IDs und Gruppennummern.

        Args:
            user_ids (List[str]): Liste von Benutzer-IDs.
            groupnumbers (List[int]): Zuordnende Gruppennummern.

        Returns:
            None

        Raises:
            None
        """
        groups: dict = {}

        # Initialize groups dictionary
        for user_id, groupnum in zip(user_ids, groupnumbers):
            if groupnum not in groups:
                groups[groupnum] = []
            groups[groupnum].append(user_id)

        # Union nodes within each group
        for groupnum, members in groups.items():
            if len(members) > 1:
                # set first user as root node of the tree representing a set (eine Praktikumsgruppe)
                first_id = members[0]
                # union other user id's with set (füge weitere Studierende zu Praktikumsgruppe hinzu)
                for user_id in members[1:]:
                    self.union(first_id, user_id)

        del groups

    # *** PUBLIC GET methods ***

    def get_groupmembers(self, user_id: str) -> List[str]:
        """Gibt eine Liste aller Gruppenmitglieder der Gruppe des Benutzers zurück.

        Args:
            user_id (str): Benutzer-ID.

        Returns:
            List[str]: Liste von Benutzer-IDs der Gruppenmitglieder.

        Raises:
            KeyError: Falls `user_id` nicht im Wörterbuch existiert.
        """
        root = self.find_byid(user_id)
        return [n.id() for n in self.values() if self.find(n) == root]

    def print_ds(self) -> None:
        """Gibt die Disjoint-Set-Struktur aus.

        Args:
            None

        Returns:
            None

        Raises:
            None
        """
        for user_id, user in self.items():
            print(user_id, self[user_id].parent().id())

    # *** PUBLIC STATIC methods ***

    # *** PRIVATE methods ***

    # *** PUBLIC methods to return class properties ***

    # *** PRIVATE variables ***
