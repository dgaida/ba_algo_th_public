# Status: FINAL, dgaida2, 15.10.2024

# Definiert die Klassen Praktikumsgruppen und SetNode, implementiert als Menge von disjunkten Mengen
#
import marketplace.user


class SetNode:
    """
    Class representing a node in a disjoint set (union-find) structure.

    Attributes:
        _parent (SetNode): The parent node in the union-find structure.
        _weight (int): The weight (number of nodes) of the (sub-)tree rooted in the current node.
    """

    # *** CONSTRUCTORS ***
    def __init__(self):
        """
        Initializes a new SetNode.
        """
        self._parent = self   # parent Knoten des SetNode Objekts. self bedeutet, dass der Knoten ein Wurzelknoten ist
        self._weight = 1      # Gewicht (Anzahl Knoten) des (Teil-)Baumes, der in dem SetNode Objekt verwurzelt ist
        # Alternative: Rank-based Quick Union
        # self._rank = 0

    # *** PUBLIC SET methods ***

    # TODO: implementieren Sie in Praktikum 3 die benötigten Methoden

    # *** PUBLIC methods to return class properties ***

    # TODO: implementieren Sie in Praktikum 3 die benötigten Methoden

class Praktikumsgruppen(dict):
    """
    Class representing a collection of disjoint sets for grouping users into practical groups.

    Methods:
        find(node): Finds the root of the set containing the node, with path compression.
        find_byid(user_id, return_id=False): Finds the root of the set containing the user by ID.
        union(user_id1, user_id2): Unions the sets containing the two users.
        create_groups(user_ids, groupnumbers): Creates groups from the provided user IDs and group numbers.
        get_groupmembers(user_id): Gets the members of the group containing the user.
        print_ds(): Prints the disjoint set structure.
    """

    # *** CONSTRUCTORS ***
    def __init__(self):
        """
        Initializes a new Praktikumsgruppen object.
        """
        super().__init__()

    # *** PUBLIC methods ***

    def find(self, node):
        """
        Finds the root of the set containing the node, with path compression.

        Args:
            node (marketplace.user.User): The node to find.

        Returns:
            marketplace.user.User: The root of the set containing the node.
        """
        if node.parent() != node:
            node.set_parent(self.find(node.parent()))  # Path compression
        return node.parent()

    def find_byid(self, user_id, return_id=False):
        """
        Finds the root of the set (Praktikumsgruppe) containing the user by ID.

        Args:
            user_id (str): The ID of the user.
            return_id (bool): Whether to return the ID of the root node (True) or the root node itself (False, default).

        Returns:
            SetNode or str: The root node or its ID, depending on return_id.
        """
        # dieses node Objekt ist ein marketplace.user.User Objekt, da in users im Konstruktor alle User Objekte
        # in Hashtabelle von Users gespeichert wurden. auf diese wird hier zugegriffen
        node = self[user_id]
        root = self.find(node)

        if return_id:
            return root.id()
        else:
            return root

    def union(self, user_id1, user_id2):
        """
        Unions the sets containing the two users. Merges two Praktikumsgruppen into one.

        Args:
            user_id1 (str): The ID of the first user.
            user_id2 (str): The ID of the second user.
        """
        root1 = self.find_byid(user_id1)
        root2 = self.find_byid(user_id2)

        if root1 != root2:
            if root1.weight() > root2.weight():
                root2.set_parent(root1)
                root1.inc_weight(root2.weight())
            # elif root1.rank() < root2.rank():
            #   root1.set_parent(root2)
            else:
                root1.set_parent(root2)
                root2.inc_weight(root1.weight())
                # root1.inc_rank()

    def create_groups(self, user_ids, groupnumbers):
        """
        Creates groups from the provided user IDs and group numbers.

        Args:
            user_ids (list): A list of user IDs.
            groupnumbers (list): A list of group numbers corresponding to the user IDs.
        """
        # TODO: implement in Praktikum 1
        pass

    # *** PUBLIC GET methods ***

    def get_groupmembers(self, user_id):
        """
        Gets the members of the group containing the user.

        Args:
            user_id (str): The ID of the user.

        Returns:
            list: A list of user IDs in the same group.
        """
        # TODO: implement in Praktikum 1
        pass

    def print_ds(self):
        """
        Prints the disjoint set structure.
        """
        for user_id, user in self.items():
            print(user_id, self[user_id].parent().id())

    # *** PUBLIC STATIC methods ***

    # *** PRIVATE methods ***

    # *** PUBLIC methods to return class properties ***

    # *** PRIVATE variables ***
