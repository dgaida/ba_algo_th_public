"""Übersicht über den Dateiinhalt:

Testdatei für die `MaxHeap`-Klasse. Prüft Heap-Operationen wie Hinzufügen,
Aktualisieren, Entfernen sowie das Verhalten bei doppelten Einträgen.
"""

import pytest
from marketplace.max_heap import MaxHeap


def test_max_heap_operations() -> None:
    """Testet Standard-Heap-Operationen (Hinzufügen, Auslesen der Spitze, Update, Entfernen).

    Args:
        None

    Returns:
        None

    Raises:
        AssertionError: Wenn Heap-Ergebnisse nicht den Erwartungen entsprechen.
    """
    heap: MaxHeap = MaxHeap()
    heap.add_auction("a1", 5)
    heap.add_auction("a2", 10)
    heap.add_auction("a3", 3)

    assert heap.get_auction_with_max_bidders() == (10, "a2")
    assert heap.get_auction_bidders("a1") == 5

    heap.update_bidders("a3", 15)
    assert heap.get_auction_with_max_bidders() == (15, "a3")

    heap.remove("a3")
    assert heap.get_auction_with_max_bidders() == (10, "a2")


def test_max_heap_duplicate_add_raises() -> None:
    """Testet, dass das Hinzufügen einer bereits existierenden Auktion eine ValueError-Exception auslöst.

    Args:
        None

    Returns:
        None

    Raises:
        AssertionError: Wenn `ValueError` nicht ausgelöst wird.
    """
    heap: MaxHeap = MaxHeap()
    heap.add_auction("a1", 5)
    with pytest.raises(ValueError):
        heap.add_auction("a1", 10)
