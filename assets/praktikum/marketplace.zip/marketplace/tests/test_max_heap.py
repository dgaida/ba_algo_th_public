import pytest
from marketplace.max_heap import MaxHeap


def test_max_heap_operations():
    heap = MaxHeap()
    heap.add_auction("a1", 5)
    heap.add_auction("a2", 10)
    heap.add_auction("a3", 3)

    assert heap.get_auction_with_max_bidders() == (10, "a2")
    assert heap.get_auction_bidders("a1") == 5

    heap.update_bidders("a3", 15)
    assert heap.get_auction_with_max_bidders() == (15, "a3")

    heap.remove("a3")
    assert heap.get_auction_with_max_bidders() == (10, "a2")


def test_max_heap_duplicate_add_raises():
    heap = MaxHeap()
    heap.add_auction("a1", 5)
    with pytest.raises(ValueError):
        heap.add_auction("a1", 10)
