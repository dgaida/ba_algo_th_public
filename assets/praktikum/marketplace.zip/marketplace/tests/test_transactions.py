from datetime import datetime
from marketplace.transactions import Transaction, Transactions


def test_transactions_insert_and_collisions():
    tx_table = Transactions(capacity=16)

    tx1 = Transaction("seller1", "buyer1", 50.0, datetime.now(), "laptop")
    tx2 = Transaction("seller2", "buyer2", 30.0, datetime.now(), "lamp")

    tx_table.insert(tx1)
    assert tx_table.get_size() == 1
    assert tx_table.get_collisions() == 0

    # tx2 has product_name starting with 'l', which collides with 'laptop' bucket
    tx_table.insert(tx2)
    assert tx_table.get_size() == 2
    assert tx_table.get_collisions() == 1
