from marketplace.trie import Trie


def test_trie_insert_and_search():
    trie = Trie()
    words = ["laptop", "lamp", "laser", "phone", "photo"]
    for word in words:
        trie.insert(word)

    results_la = trie.search("la")
    assert sorted(results_la) == ["lamp", "laptop", "laser"]

    results_ph = trie.search("ph")
    assert sorted(results_ph) == ["phone", "photo"]

    results_xyz = trie.search("xyz")
    assert results_xyz == []
