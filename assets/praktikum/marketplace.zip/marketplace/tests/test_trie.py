"""Übersicht über den Dateiinhalt:

Testdatei für die `Trie`-Klasse. Prüft das Einfügen von Wörtern und die Präfix-Suche.
"""

from marketplace.trie import Trie


def test_trie_insert_and_search() -> None:
    """Testet das Einfügen von Wörtern in den Trie und das Durchsuchen nach Präfixen.

    Args:
        None

    Returns:
        None

    Raises:
        AssertionError: Wenn die Trefferliste für ein Präfix nicht den erwarteten Wörtern entspricht.
    """
    trie: Trie = Trie()
    words = ["laptop", "lamp", "laser", "phone", "photo"]
    for word in words:
        trie.insert(word)

    results_la = trie.search("la")
    assert sorted(results_la) == ["lamp", "laptop", "laser"]

    results_ph = trie.search("ph")
    assert sorted(results_ph) == ["phone", "photo"]

    results_xyz = trie.search("xyz")
    assert results_xyz == []
