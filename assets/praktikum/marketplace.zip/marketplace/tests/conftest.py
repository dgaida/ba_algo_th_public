"""Übersicht über den Dateiinhalt:

Konfigurationsdatei für pytest. Fügt die relevanten Verzeichnisse
von praktikum/marketplace zum Python-Pfad hinzu.
"""

import sys
from pathlib import Path

tests_dir: Path = Path(__file__).resolve().parent
marketplace_dir: Path = tests_dir.parent
praktikum_dir: Path = marketplace_dir.parent

for d in (str(marketplace_dir), str(praktikum_dir)):
    if d not in sys.path:
        sys.path.insert(0, d)
