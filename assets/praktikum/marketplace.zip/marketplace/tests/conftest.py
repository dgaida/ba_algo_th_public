import sys
from pathlib import Path

tests_dir = Path(__file__).resolve().parent
marketplace_dir = tests_dir.parent
praktikum_dir = marketplace_dir.parent

for d in (str(marketplace_dir), str(praktikum_dir)):
    if d not in sys.path:
        sys.path.insert(0, d)
