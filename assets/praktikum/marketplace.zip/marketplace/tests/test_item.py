from marketplace.item import Item


def test_item_creation_and_properties():
    item = Item("Laptop", "Ein gebrauchter Laptop", 250.0)
    assert item.name() == "Laptop"
    assert item.description() == "Ein gebrauchter Laptop"
    assert item.value_min() == 250.0
