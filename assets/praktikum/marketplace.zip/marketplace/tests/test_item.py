"""Übersicht über den Dateiinhalt:

Testdatei für die `Item`-Klasse. Prüft die Erstellung und Attribut-Getter eines Artikels.
"""

from marketplace.item import Item


def test_item_creation_and_properties() -> None:
    """Testet die Erstellung eines `Item`-Objekts und dessen Getter-Methoden.

    Args:
        None

    Returns:
        None

    Raises:
        AssertionError: Wenn die Eigenschaften des Items nicht den erwarteten Werten entsprechen.
    """
    item: Item = Item("Laptop", "Ein gebrauchter Laptop", 250.0)
    assert item.name() == "Laptop"
    assert item.description() == "Ein gebrauchter Laptop"
    assert item.value_min() == 250.0
