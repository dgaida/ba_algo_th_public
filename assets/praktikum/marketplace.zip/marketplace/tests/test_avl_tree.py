"""Übersicht über den Dateiinhalt:

Testdatei für die `AVLTree`-Klasse. Prüft das Einfügen, Suchen, Auffinden von
Knoten sowie die Ermittlung häufig gesuchter Wörter anhand eines Präfix.
"""

from marketplace.avl_tree import AVLTree


def test_avl_tree_insert_and_find() -> None:
    """Testet das Einfügen und Suchen von Schlüssel-Wert-Paaren im AVL-Baum.

    Args:
        None

    Returns:
        None

    Raises:
        AssertionError: Wenn die Such- oder Find-Ergebnisse nicht mit den Erwartungen übereinstimmen.
    """
    tree: AVLTree = AVLTree()
    tree.insert("laptop", 10)
    tree.insert("lamp", 5)
    tree.insert("laser", 8)

    assert tree.search("laptop") is True
    assert tree.search("phone") is False

    node = tree.find("laptop")
    assert node is not None
    assert node.key == "laptop"


def test_avl_tree_find_most_likely_words() -> None:
    """Testet das Finden der wahrscheinlichsten Wörter für ein gegebenes Präfix.

    Args:
        None

    Returns:
        None

    Raises:
        AssertionError: Wenn die Reihenfolge oder Auswahl der vorgeschlagenen Wörter fehlerhaft ist.
    """
    tree: AVLTree = AVLTree()
    tree.insert("laptop", 10)
    tree.insert("lamp", 5)
    tree.insert("laser", 15)

    suggestions = tree.find_most_likely_words("la")
    # laser has count 15, laptop has count 10, lamp has count 5
    assert suggestions == ["laser", "laptop", "lamp"]
