from marketplace.avl_tree import AVLTree


def test_avl_tree_insert_and_find():
    tree = AVLTree()
    tree.insert("laptop", 10)
    tree.insert("lamp", 5)
    tree.insert("laser", 8)

    assert tree.search("laptop") is True
    assert tree.search("phone") is False

    node = tree.find("laptop")
    assert node is not None
    assert node.key == "laptop"


def test_avl_tree_find_most_likely_words():
    tree = AVLTree()
    tree.insert("laptop", 10)
    tree.insert("lamp", 5)
    tree.insert("laser", 15)

    suggestions = tree.find_most_likely_words("la")
    # laser has count 15, laptop has count 10, lamp has count 5
    assert suggestions == ["laser", "laptop", "lamp"]
