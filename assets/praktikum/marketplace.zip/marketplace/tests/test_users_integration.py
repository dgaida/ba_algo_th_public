"""Übersicht über den Dateiinhalt:

Integrationstest-Datei für die `Users`-Klasse. Prüft die Freundschaftsverbindung,
Freundschaftsempfehlungen sowie die Entfernungsberechnung zwischen Benutzern.
"""

from typing import Any
import os
import pytest
from marketplace.users import Users


@pytest.fixture
def sample_users(tmp_path: Any) -> Users:
    """Pytest Fixture zur Erstellung einer temporären Test-Umgebung mit Benutzern.

    Args:
        tmp_path (Any): Temporärer Verzeichnispfad von Pytest.

    Returns:
        Users: Initialisierte `Users`-Instanz mit Testdaten.

    Raises:
        Exception: Falls Dateierstellung oder Einlesen fehlschlägt.
    """
    users_csv = tmp_path / "user.csv"
    friends_csv = tmp_path / "friends.csv"

    users_csv.write_text(
        "user_id,name_family,name_first,password,groupnum,gps_coords,address\n"
        "user1,Doe,John,abcde,1,\"(50.98, 7.54)\",Gummersbach\n"
        "user2,Smith,Jane,abcde,1,\"(50.99, 7.55)\",Gummersbach\n"
        "user3,Bond,James,abcde,2,\"(51.00, 7.56)\",Gummersbach\n"
        "user4,Wayne,Bruce,abcde,2,\"(51.01, 7.57)\",Gummersbach\n",
        encoding="utf-8"
    )

    friends_csv.write_text(
        "user_id,friends\n"
        "user1,user2, user3\n"
        "user4,user2, user3\n",
        encoding="utf-8"
    )

    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        u = Users(str(users_csv))
    finally:
        os.chdir(cwd)

    return u


def test_are_users_connected(sample_users: Users) -> None:
    """Testet die Prüfung, ob zwei Benutzer über Ecken befreundet sind.

    Args:
        sample_users (Users): Die Fixture-Instanz der Benutzerverwaltung.

    Returns:
        None

    Raises:
        AssertionError: Wenn der Verbindungsstatus fehlerhaft ermittelt wird.
    """
    assert sample_users.are_users_connected("user1", "user4", degree=3) is True
    assert sample_users.are_users_connected("user1", "nonexistent", degree=3) is False


def test_suggest_friends(sample_users: Users) -> None:
    """Testet die Generierung von Freundschaftsempfehlungen.

    Args:
        sample_users (Users): Die Fixture-Instanz der Benutzerverwaltung.

    Returns:
        None

    Raises:
        AssertionError: Wenn die Empfehlung nicht die erwartete Benutzer-ID enthält.
    """
    suggestions = sample_users.suggest_friends("user1", num_common_friends=1, pretty_print=False)
    assert "user4" in suggestions


def test_calc_distance_between_users(sample_users: Users) -> None:
    """Testet die Abstandsberechnung zwischen zwei Benutzern.

    Args:
        sample_users (Users): Die Fixture-Instanz der Benutzerverwaltung.

    Returns:
        None

    Raises:
        AssertionError: Wenn der berechnete Abstand nicht größer als 0 ist.
    """
    dist = sample_users.calc_distance_between_users("user1", "user2")
    assert dist > 0
