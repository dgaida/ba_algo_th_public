import pytest
from marketplace.user import User


def test_user_creation_and_properties():
    user = User("m12345", "abcde", "Mustermann", "Erika", (50.98, 7.54), "Gummersbach")
    assert user.id() == "m12345"
    assert user.password() == "abcde"
    assert user.name() == "Erika Mustermann"
    assert user.address() == "Gummersbach"
    assert user.gps_coords() == (50.98, 7.54)
    assert user.balance() == 500.0


def test_user_password_validity():
    user = User("m12345", "abcde", "Mustermann", "Erika", (50.98, 7.54), "Gummersbach")
    assert user.password_valid("abcde") is True
    assert user.password_valid("wrong") is False


def test_user_balance_modification():
    user = User("m12345", "abcde", "Mustermann", "Erika", (50.98, 7.54), "Gummersbach")
    user.decrease_balance(50.0)
    assert user.balance() == 450.0
    user.increase_balance(100.0)
    assert user.balance() == 550.0


def test_user_friend_management():
    user = User("m12345", "abcde", "Mustermann", "Erika", (50.98, 7.54), "Gummersbach")
    user.friends_add("f100")
    assert user.is_friend("f100") is True
    user.friends_add_list(["f200", "f300"])
    assert user.is_friend("f200") is True
    assert user.is_friend("f300") is True
    user.friends_delete("f100")
    assert user.is_friend("f100") is False


def test_user_rating():
    user = User("m12345", "abcde", "Mustermann", "Erika", (50.98, 7.54), "Gummersbach")
    assert user.get_rating_stars_mean() == 0
    user.rate_user(5)
    user.rate_user(3)
    assert user.get_rating_stars_mean() == 4.0
