from marketplace.user import User
from marketplace.praktikumsgruppen import SetNode, Praktikumsgruppen


def test_set_node():
    node = SetNode()
    assert node.parent() == node
    assert node.weight() == 1

    node.inc_weight(2)
    assert node.weight() == 3

    parent_node = SetNode()
    node.set_parent(parent_node)
    assert node.parent() == parent_node


def test_praktikumsgruppen_union_find():
    pg = Praktikumsgruppen()

    u1 = User("u1", "abc", "Nachname1", "Vorname1", (50.0, 7.0), "Ort1")
    u2 = User("u2", "abc", "Nachname2", "Vorname2", (50.0, 7.0), "Ort2")
    u3 = User("u3", "abc", "Nachname3", "Vorname3", (50.0, 7.0), "Ort3")

    pg["u1"] = u1
    pg["u2"] = u2
    pg["u3"] = u3

    pg.create_groups(["u1", "u2", "u3"], [1, 1, 2])

    members_group1 = pg.get_groupmembers("u1")
    assert sorted(members_group1) == ["u1", "u2"]

    members_group2 = pg.get_groupmembers("u3")
    assert members_group2 == ["u3"]
